'use strict';

const DAYS = ['월', '화', '수', '목', '금'];
const PERIODS = [1, 2, 3, 4, 5, 6, 7];
const STORAGE_KEY = 'timetableShare.students.v1';

function normalizeName(value) {
  const compact = String(value ?? '').trim().replace(/\s+/g, ' ');
  if (!compact) return '';
  const parts = compact.split(' ');
  const allHangul = parts.every((part) => /^\p{Script=Hangul}+$/u.test(part));
  return allHangul ? parts.join('') : compact;
}

function createDemoSchedule() {
  return {
    월: ['스포츠 생활2', '생명과학 실험', '화학 실험', '화학 실험', '한국사2', '한국사2', '공강'],
    화: ['고급 대수', '고급 대수', '고급 미적분', '고급 미적분', '물리학 실험', '화법과 언어', '화법과 언어'],
    수: ['음악 감상과 비평', '음악 감상과 비평', '인공지능 일반', '고급 대수', '한국사2', '창체', '창체'],
    목: ['생명과학 실험', '생명과학 실험', '스포츠 생활2', '스포츠 생활2', '인공지능 일반', '인공지능 일반', '공강'],
    금: ['화학 실험', '물리학 실험', '물리학 실험', '화법과 언어', '음악 감상과 비평', '고급 미적분', '공강'],
  };
}

function normalizeSchedule(schedule = {}) {
  return DAYS.reduce((result, day) => {
    const source = Array.isArray(schedule[day]) ? schedule[day] : [];
    result[day] = PERIODS.map((_, index) => String(source[index] ?? '').trim());
    return result;
  }, {});
}

function isFreeSubject(subject) {
  const normalized = String(subject ?? '').trim();
  return normalized === '' || normalized === '공강';
}

function validateStudentDraft(name, schedule) {
  const normalizedName = normalizeName(name);
  if (!normalizedName) {
    return { ok: false, message: '학생 이름을 입력해주세요.' };
  }

  if (!schedule || typeof schedule !== 'object') {
    return { ok: false, message: '먼저 시간표 이미지를 분석해주세요.' };
  }

  const normalizedSchedule = normalizeSchedule(schedule);
  const tooLong = DAYS.some((day) => normalizedSchedule[day].some((subject) => subject.length > 60));
  if (tooLong) {
    return { ok: false, message: '과목명은 60자 이내로 입력해주세요.' };
  }

  return { ok: true, name: normalizedName, schedule: normalizedSchedule };
}

function getStudentsAt(students, day, period) {
  const periodIndex = PERIODS.indexOf(Number(period));
  if (!DAYS.includes(day) || periodIndex < 0) return [];

  return (Array.isArray(students) ? students : []).map((student) => {
    const subject = normalizeSchedule(student.schedule)[day][periodIndex];
    const free = isFreeSubject(subject);
    return {
      name: normalizeName(student.name),
      subject: free ? '공강' : subject,
      isFree: free,
    };
  });
}

function findFreeStudents(students, day, period) {
  return getStudentsAt(students, day, period).filter((item) => item.isFree);
}

function loadStudents(storage) {
  try {
    const raw = storage?.getItem?.(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed
      .filter((student) => student && normalizeName(student.name))
      .map((student) => ({
        name: normalizeName(student.name),
        updatedAt: typeof student.updatedAt === 'string' ? student.updatedAt : '',
        schedule: normalizeSchedule(student.schedule),
      }));
  } catch {
    return [];
  }
}

function saveStudents(storage, students) {
  storage?.setItem?.(STORAGE_KEY, JSON.stringify(Array.isArray(students) ? students : []));
}

function upsertStudent(students, student) {
  const nextStudent = {
    ...student,
    name: normalizeName(student?.name),
    schedule: normalizeSchedule(student?.schedule),
  };
  const next = Array.isArray(students) ? students.filter(Boolean).map((item) => ({ ...item })) : [];
  const index = next.findIndex((item) => normalizeName(item.name) === nextStudent.name);
  if (index >= 0) next.splice(index, 1);
  next.unshift(nextStudent);
  return next;
}

function initApp(doc = document, storage = localStorage) {
  const elements = {
    studentName: doc.getElementById('studentName'),
    scheduleImage: doc.getElementById('scheduleImage'),
    imagePreviewWrap: doc.getElementById('imagePreviewWrap'),
    imagePreview: doc.getElementById('imagePreview'),
    analyzeBtn: doc.getElementById('analyzeBtn'),
    analysisPanel: doc.getElementById('analysisPanel'),
    editableScheduleWrap: doc.getElementById('editableScheduleWrap'),
    saveBtn: doc.getElementById('saveBtn'),
    lookupSearch: doc.getElementById('lookupSearch'),
    studentList: doc.getElementById('studentList'),
    lookupDay: doc.getElementById('lookupDay'),
    lookupPeriod: doc.getElementById('lookupPeriod'),
    timeLookupBtn: doc.getElementById('timeLookupBtn'),
    timeLookupResults: doc.getElementById('timeLookupResults'),
    studentScheduleCard: doc.getElementById('studentScheduleCard'),
    selectedStudentTitle: doc.getElementById('selectedStudentTitle'),
    selectedStudentUpdated: doc.getElementById('selectedStudentUpdated'),
    readonlyScheduleWrap: doc.getElementById('readonlyScheduleWrap'),
    freeDay: doc.getElementById('freeDay'),
    freePeriod: doc.getElementById('freePeriod'),
    freeLookupBtn: doc.getElementById('freeLookupBtn'),
    freeCount: doc.getElementById('freeCount'),
    freeResults: doc.getElementById('freeResults'),
    toast: doc.getElementById('toast'),
  };

  const state = {
    students: loadStudents(storage),
    draftSchedule: null,
    selectedStudentName: '',
    previewUrl: '',
    toastTimer: null,
  };

  fillSelect(elements.lookupDay, DAYS, (day) => `${day}요일`);
  fillSelect(elements.freeDay, DAYS, (day) => `${day}요일`);
  fillSelect(elements.lookupPeriod, PERIODS, (period) => `${period}교시`);
  fillSelect(elements.freePeriod, PERIODS, (period) => `${period}교시`);

  doc.querySelectorAll('[data-nav]').forEach((button) => {
    button.addEventListener('click', () => {
      switchView(doc, button.dataset.nav);
      if (button.dataset.nav === 'lookup') {
        renderStudentList(doc, elements, state);
        renderTimeLookup(doc, elements, state);
      }
      if (button.dataset.nav === 'free') {
        renderFreeLookup(doc, elements, state);
      }
    });
  });

  elements.studentName.addEventListener('blur', () => {
    elements.studentName.value = normalizeName(elements.studentName.value);
  });

  elements.scheduleImage.addEventListener('change', () => {
    const file = elements.scheduleImage.files?.[0];
    if (state.previewUrl) {
      URL.revokeObjectURL(state.previewUrl);
      state.previewUrl = '';
    }

    if (!file) {
      elements.imagePreview.removeAttribute('src');
      elements.imagePreviewWrap.hidden = true;
      return;
    }

    if (!file.type.startsWith('image/')) {
      elements.scheduleImage.value = '';
      elements.imagePreview.removeAttribute('src');
      elements.imagePreviewWrap.hidden = true;
      showToast(elements, state, '이미지 파일만 선택할 수 있습니다.', true);
      return;
    }

    state.previewUrl = URL.createObjectURL(file);
    elements.imagePreview.src = state.previewUrl;
    elements.imagePreviewWrap.hidden = false;
  });

  elements.analyzeBtn.addEventListener('click', () => {
    const name = normalizeName(elements.studentName.value);
    if (!name) {
      showToast(elements, state, '학생 이름을 먼저 입력해주세요.', true);
      elements.studentName.focus();
      return;
    }

    const file = elements.scheduleImage.files?.[0];
    if (!file) {
      showToast(elements, state, '분석할 시간표 이미지를 선택해주세요.', true);
      elements.scheduleImage.focus();
      return;
    }

    elements.studentName.value = name;
    setButtonLoading(elements.analyzeBtn, true, '분석 중...');

    window.setTimeout(() => {
      state.draftSchedule = createDemoSchedule();
      renderEditableSchedule(doc, elements.editableScheduleWrap, state.draftSchedule);
      elements.analysisPanel.hidden = false;
      setButtonLoading(elements.analyzeBtn, false);
      elements.analysisPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 450);
  });

  elements.saveBtn.addEventListener('click', () => {
    if (!state.draftSchedule) {
      showToast(elements, state, '먼저 시간표 분석을 진행해주세요.', true);
      return;
    }

    const editedSchedule = collectEditedSchedule(elements.editableScheduleWrap);
    const validation = validateStudentDraft(elements.studentName.value, editedSchedule);
    if (!validation.ok) {
      showToast(elements, state, validation.message, true);
      return;
    }

    setButtonLoading(elements.saveBtn, true, '저장 중...');
    window.setTimeout(() => {
      try {
        const student = {
          name: validation.name,
          updatedAt: new Date().toISOString(),
          schedule: validation.schedule,
        };
        state.students = upsertStudent(state.students, student);
        saveStudents(storage, state.students);
        state.draftSchedule = validation.schedule;
        elements.studentName.value = validation.name;
        renderStudentList(doc, elements, state);
        renderTimeLookup(doc, elements, state);
        renderFreeLookup(doc, elements, state);
        showToast(elements, state, `${validation.name} 시간표를 저장했습니다.`);
      } catch {
        showToast(elements, state, '저장하지 못했습니다. 브라우저 저장 공간을 확인해주세요.', true);
      } finally {
        setButtonLoading(elements.saveBtn, false);
      }
    }, 220);
  });

  elements.lookupSearch.addEventListener('input', () => renderStudentList(doc, elements, state));
  elements.timeLookupBtn.addEventListener('click', () => renderTimeLookup(doc, elements, state));
  elements.lookupDay.addEventListener('change', () => renderTimeLookup(doc, elements, state));
  elements.lookupPeriod.addEventListener('change', () => renderTimeLookup(doc, elements, state));
  elements.freeLookupBtn.addEventListener('click', () => renderFreeLookup(doc, elements, state));
  elements.freeDay.addEventListener('change', () => renderFreeLookup(doc, elements, state));
  elements.freePeriod.addEventListener('change', () => renderFreeLookup(doc, elements, state));

  renderStudentList(doc, elements, state);
  renderTimeLookup(doc, elements, state);
  renderFreeLookup(doc, elements, state);

  return state;
}

function fillSelect(select, values, labeler) {
  select.replaceChildren();
  values.forEach((value) => {
    const option = select.ownerDocument.createElement('option');
    option.value = String(value);
    option.textContent = labeler(value);
    select.appendChild(option);
  });
}

function switchView(doc, viewName) {
  doc.querySelectorAll('[data-view]').forEach((view) => {
    view.hidden = view.dataset.view !== viewName;
  });

  doc.querySelectorAll('[data-nav]').forEach((button) => {
    const active = button.dataset.nav === viewName;
    button.classList.toggle('is-active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });

  const main = doc.getElementById('mainContent');
  main?.scrollIntoView({ block: 'start' });
}

function renderEditableSchedule(doc, container, schedule) {
  container.replaceChildren(buildScheduleTable(doc, schedule, true));
}

function renderReadOnlySchedule(doc, container, schedule) {
  container.replaceChildren(buildScheduleTable(doc, schedule, false));
}

function buildScheduleTable(doc, schedule, editable) {
  const normalized = normalizeSchedule(schedule);
  const table = doc.createElement('table');
  table.className = 'schedule-table';

  const thead = doc.createElement('thead');
  const headerRow = doc.createElement('tr');
  const corner = doc.createElement('th');
  corner.scope = 'col';
  corner.textContent = '교시';
  headerRow.appendChild(corner);
  DAYS.forEach((day) => {
    const th = doc.createElement('th');
    th.scope = 'col';
    th.textContent = `${day}요일`;
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = doc.createElement('tbody');
  PERIODS.forEach((period, periodIndex) => {
    const row = doc.createElement('tr');
    const periodHeader = doc.createElement('th');
    periodHeader.scope = 'row';
    periodHeader.textContent = `${period}교시`;
    row.appendChild(periodHeader);

    DAYS.forEach((day) => {
      const td = doc.createElement('td');
      const subject = normalized[day][periodIndex];

      if (editable) {
        const input = doc.createElement('input');
        input.className = 'schedule-input';
        input.type = 'text';
        input.maxLength = 60;
        input.value = subject;
        input.dataset.day = day;
        input.dataset.period = String(period);
        input.setAttribute('aria-label', `${day}요일 ${period}교시 과목명`);
        td.appendChild(input);
      } else {
        const free = isFreeSubject(subject);
        td.className = `schedule-cell${free ? ' is-free' : ''}`;
        td.textContent = free ? '공강' : subject;
      }
      row.appendChild(td);
    });
    tbody.appendChild(row);
  });
  table.appendChild(tbody);
  return table;
}

function collectEditedSchedule(container) {
  const schedule = normalizeSchedule({});
  container.querySelectorAll('.schedule-input').forEach((input) => {
    const day = input.dataset.day;
    const periodIndex = Number(input.dataset.period) - 1;
    if (DAYS.includes(day) && periodIndex >= 0 && periodIndex < PERIODS.length) {
      schedule[day][periodIndex] = input.value.trim();
    }
  });
  return schedule;
}

function renderStudentList(doc, elements, state) {
  const query = normalizeName(elements.lookupSearch.value).toLocaleLowerCase('ko-KR');
  const filtered = state.students.filter((student) => student.name.toLocaleLowerCase('ko-KR').includes(query));
  elements.studentList.replaceChildren();

  if (!state.students.length) {
    elements.studentList.appendChild(createEmptyState(doc, '아직 저장된 시간표가 없습니다. 먼저 시간표를 등록해보세요.'));
    elements.studentScheduleCard.hidden = true;
    return;
  }

  if (!filtered.length) {
    elements.studentList.appendChild(createEmptyState(doc, '검색 결과가 없습니다. 다른 이름으로 찾아보세요.'));
    return;
  }

  filtered.forEach((student) => {
    const button = doc.createElement('button');
    button.type = 'button';
    button.className = 'student-button';
    button.setAttribute('aria-label', `${student.name} 전체 시간표 보기`);

    const textWrap = doc.createElement('div');
    const name = doc.createElement('strong');
    name.textContent = student.name;
    const updated = doc.createElement('span');
    updated.textContent = student.updatedAt ? `업데이트 ${formatUpdatedAt(student.updatedAt)}` : '저장된 시간표';
    textWrap.append(name, updated);

    const action = doc.createElement('strong');
    action.textContent = '보기';
    action.style.color = 'var(--primary)';

    button.append(textWrap, action);
    button.addEventListener('click', () => selectStudent(doc, elements, state, student.name));
    elements.studentList.appendChild(button);
  });
}

function selectStudent(doc, elements, state, studentName) {
  const student = state.students.find((item) => item.name === studentName);
  if (!student) return;
  state.selectedStudentName = student.name;
  elements.selectedStudentTitle.textContent = `${student.name} 시간표`;
  elements.selectedStudentUpdated.textContent = student.updatedAt ? `마지막 저장: ${formatUpdatedAt(student.updatedAt)}` : '';
  renderReadOnlySchedule(doc, elements.readonlyScheduleWrap, student.schedule);
  elements.studentScheduleCard.hidden = false;
  elements.studentScheduleCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderTimeLookup(doc, elements, state) {
  const day = elements.lookupDay.value || DAYS[0];
  const period = Number(elements.lookupPeriod.value || PERIODS[0]);
  const rows = getStudentsAt(state.students, day, period);
  elements.timeLookupResults.replaceChildren();

  if (!rows.length) {
    elements.timeLookupResults.appendChild(createEmptyState(doc, '저장된 학생이 없어 조회할 수 없습니다.'));
    return;
  }

  rows.forEach((row) => {
    const item = doc.createElement('div');
    item.className = `result-item${row.isFree ? ' is-free' : ''}`;
    const name = doc.createElement('strong');
    name.textContent = row.name;
    const subject = doc.createElement('span');
    subject.textContent = `${day}요일 ${period}교시 · ${row.subject}`;
    item.append(name, subject);
    elements.timeLookupResults.appendChild(item);
  });
}

function renderFreeLookup(doc, elements, state) {
  const day = elements.freeDay.value || DAYS[0];
  const period = Number(elements.freePeriod.value || PERIODS[0]);
  const freeStudents = findFreeStudents(state.students, day, period);
  elements.freeCount.textContent = `${freeStudents.length}명`;
  elements.freeResults.replaceChildren();

  if (!state.students.length) {
    elements.freeResults.appendChild(createEmptyState(doc, '아직 저장된 학생이 없습니다. 시간표를 등록하면 공강을 찾을 수 있습니다.'));
    return;
  }

  if (!freeStudents.length) {
    elements.freeResults.appendChild(createEmptyState(doc, `${day}요일 ${period}교시에는 공강인 학생이 없습니다.`));
    return;
  }

  freeStudents.forEach((student) => {
    const item = doc.createElement('div');
    item.className = 'result-item is-free';
    const name = doc.createElement('strong');
    name.textContent = student.name;
    const meta = doc.createElement('span');
    meta.textContent = `${day}요일 ${period}교시 · 공강`;
    item.append(name, meta);
    elements.freeResults.appendChild(item);
  });
}

function createEmptyState(doc, message) {
  const div = doc.createElement('div');
  div.className = 'empty-state';
  div.textContent = message;
  return div;
}

function formatUpdatedAt(isoString) {
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return '날짜 정보 없음';
  return new Intl.DateTimeFormat('ko-KR', {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function setButtonLoading(button, loading, loadingText = '처리 중...') {
  if (loading) {
    if (!button.dataset.originalText) button.dataset.originalText = button.textContent;
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    button.textContent = loadingText;
    return;
  }
  button.disabled = false;
  button.removeAttribute('aria-busy');
  button.textContent = button.dataset.originalText || button.textContent;
}

function showToast(elements, state, message, isError = false) {
  if (state.toastTimer) window.clearTimeout(state.toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.toggle('is-error', isError);
  elements.toast.setAttribute('role', isError ? 'alert' : 'status');
  elements.toast.hidden = false;
  state.toastTimer = window.setTimeout(() => {
    elements.toast.hidden = true;
  }, 2800);
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    initApp(document, window.localStorage);
  });
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DAYS,
    PERIODS,
    STORAGE_KEY,
    normalizeName,
    createDemoSchedule,
    normalizeSchedule,
    isFreeSubject,
    validateStudentDraft,
    getStudentsAt,
    findFreeStudents,
    loadStudents,
    saveStudents,
    upsertStudent,
    initApp,
  };
}
